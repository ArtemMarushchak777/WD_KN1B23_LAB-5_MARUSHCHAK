const sections = document.querySelectorAll('.content-section');
const sectionButtons = document.querySelectorAll('[data-section]');
const form = document.querySelector('#supportForm');
const submitBtn = document.querySelector('#submitBtn');
const statusBox = document.querySelector('#formStatus');

function showSection(sectionId) {
  sections.forEach((section) => {
    section.classList.toggle('active', section.id === sectionId);
  });

  sectionButtons.forEach((button) => {
    button.classList.toggle('active', button.dataset.section === sectionId);
  });
}

// Делегування подій: один обробник реагує на кліки по всіх кнопках з data-section.
document.addEventListener('click', (event) => {
  const button = event.target.closest('[data-section]');
  if (!button) return;

  const sectionId = button.dataset.section;
  if (document.getElementById(sectionId)) {
    showSection(sectionId);
  }
});

function setError(fieldName, message) {
  const errorElement = document.querySelector(`[data-error="${fieldName}"]`);
  if (errorElement) {
    errorElement.textContent = message;
  }
}

function clearErrors() {
  document.querySelectorAll('.error').forEach((element) => {
    element.textContent = '';
  });
  statusBox.textContent = '';
  statusBox.className = 'status';
}

function validateEmail(email) {
  const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return pattern.test(email);
}

function validateForm(formData) {
  let isValid = true;

  if (formData.fullName.trim().length < 3) {
    setError('fullName', 'Введіть ім\'я та прізвище не коротше 3 символів.');
    isValid = false;
  }

  if (!validateEmail(formData.email)) {
    setError('email', 'Введіть коректну адресу електронної пошти.');
    isValid = false;
  }

  if (!formData.participation) {
    setError('participation', 'Оберіть формат участі.');
    isValid = false;
  }

  if (Number.isNaN(formData.donation) || formData.donation < 0) {
    setError('donation', 'Сума донату не може бути від\'ємною.');
    isValid = false;
  }

  if ((formData.participation === 'donor' || formData.participation === 'both')
      && formData.donation < 10) {
    setError('donation', 'Для донату введіть суму не менше 10 грн.');
    isValid = false;
  }

  if (!formData.consent) {
    setError('consent', 'Потрібно підтвердити згоду на обробку даних.');
    isValid = false;
  }

  return isValid;
}

function fakeSubmit(data) {
  console.log('Дані підготовлено до надсилання:', data);

  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        ok: true,
        message: 'Дякуємо! Дані успішно прийнято. Ми зв\'яжемося з вами.'
      });
    }, 1500);
  });
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  clearErrors();

  const formData = {
    fullName: form.fullName.value,
    email: form.email.value,
    participation: form.participation.value,
    donation: Number(form.donation.value),
    consent: form.consent.checked
  };

  if (!validateForm(formData)) {
    statusBox.textContent = 'Будь ласка, виправте помилки у формі.';
    statusBox.classList.add('fail');
    return;
  }

  submitBtn.disabled = true;
  submitBtn.textContent = 'Надсилання...';
  statusBox.textContent = 'Імітація надсилання даних на сервер...';

  try {
    const response = await fakeSubmit(formData);
    statusBox.textContent = response.message;
    statusBox.classList.add(response.ok ? 'success' : 'fail');
    form.reset();
  } catch (error) {
    statusBox.textContent = 'Сталася помилка. Спробуйте ще раз.';
    statusBox.classList.add('fail');
  } finally {
    submitBtn.disabled = false;
    submitBtn.textContent = 'Надіслати';
  }
});
